

<h2>TaalDoos</h2>

<img src="https://drive.google.com/uc?export=view&id=1h9JkslCrvWYhjt4J83spdG7cpAldEnGL" width=60 height=80 alt="Italian Trulli">

Hi Everybody,

'Taaldoos' (Dutch language Box) are a set of Tools for manipulating The Dutch Language.

The goal is it to create a set of tools and can be used to manipulate dutch sentences in a comprehensive way. At the moment this project is in the planning fase.
